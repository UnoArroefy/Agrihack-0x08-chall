## Time to Sleep

## Desc
import request if its time to turu then give me flag
<br>
Reff: https://requests.readthedocs.io/en/latest/

## Solution


## Flag
`agrihack{sweet_dr3ams_5}`